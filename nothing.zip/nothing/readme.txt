Add to *.vmoptions file:
--add-opens=java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED
--add-opens=java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED
-javaagent:{full_path_to_this_dir}jbcrk.jar

To run the keygen you need python3 and install the libraries from the requirements.txt file. In command line:
# pip3 install -r requirements.txt
# python3 kg.py


