import base64
import datetime
import json
import string
import os
import urllib.request, urllib.parse
import xmltodict
import random
import ssl

from Crypto.Hash import SHA1, SHA256
from Crypto.PublicKey import RSA
from Crypto.Signature import pkcs1_15
from Crypto.Util.asn1 import DerSequence, DerObjectId, DerNull, DerOctetString
from Crypto.Util.number import ceil_div
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding

def gen_licenseId():
    return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10)).upper()

# noinspection PyTypeChecker
def pkcs15_encode(msg_hash, emLen, with_hash_parameters=True):
    """
    Implement the ``EMSA-PKCS1-V1_5-ENCODE`` function, as defined
    :param msg_hash: hash object
    :param emLen: int
    :param with_hash_parameters: bool
    :return: An ``emLen`` byte long string that encodes the hash.
    """
    digestAlgo = DerSequence([DerObjectId(msg_hash.oid).encode()])

    if with_hash_parameters:
        digestAlgo.append(DerNull().encode())

    digest = DerOctetString(msg_hash.digest())
    digestInfo = DerSequence([
        digestAlgo.encode(),
        digest.encode()
    ]).encode()

    # We need at least 11 bytes for the remaining data: 3 fixed bytes and
    # at least 8 bytes of padding).
    if emLen < len(digestInfo) + 11:
        raise TypeError("Selected hash algorithm has a too long digest (%d bytes)." % len(digest))
    PS = b'\xFF' * (emLen - len(digestInfo) - 3)
    return b'\x00\x01' + PS + b'\x00' + digestInfo

ssl._create_default_https_context = ssl._create_unverified_context # disable ssl in urllib for MacOS

certBase64 = "MIIEWzCCAkOgAwIBAgIINJagMxj4QmcwDQYJKoZIhvcNAQELBQAwGDEWMBQGA1UEAwwNSmV0UHJvZmlsZSBDQTAgFw0yMjA4MTIxNTQxMzRaGA8yMDk5MTIzMDE2MDAwMFowEjEQMA4GA1UEAwwHTmFzbGxlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMcfMBkb2infMU/w5MyzYoZouQ9ghCc73hKKVlZwIl/Z/rBWyR0q73Il+cwAYC3qziUEjq+wNM4JvtdKfXtohRyWg578vqu4pbDzhudhXRqitNK7FY9yAevShabtRCEWCmGvp3gE4gEl8rorwlAKCMcYZIP1ujceEQwDss0HiQ6WhyUQ3VjI/VcH3+yjN0PfIFfz7/waEtqdXoXOP6L12jAfRA4Dg/8UjJaxFLy5+1sfiMReo61dk94vvshIr4Zebn97SidQp4/5Yb9sBTLFiXm4byhWTadmxqYJa1WzBIqag6HSFV1SOdVgGzrNp7GR65aLHWUrIBf8Hzsipbh5mxkCAwEAAaOBrDCBqTAMBgNVHRMBAf8EAjAAMA4GA1UdDwEB/wQEAwIFoDAgBgNVHSUBAf8EFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwSAYDVR0jBEEwP4AUo562SGdCEjZBvW3gubSgUouX8bOhHKQaMBgxFjAUBgNVBAMMDUpldFByb2ZpbGUgQ0GCCQDSbLGDsoN54TAdBgNVHQ4EFgQUM3Gc1UMiRTvhB7NrJzTB2i0QIpIwDQYJKoZIhvcNAQELBQADggIBAE3rgtdbxFiPN1KtXTVW7vDHJmyo9YFiNCMRLoQiwHC4qpM2oAU1qj+NzSyQ01t4dMR4gEpETlaYmrVKpwL1ltH0zA1jV/c/gI5PNJmVNbO2ylPHWoY23pVt3xVCQii657iimbdxRABrjYWeBGviI/0t8XkYDx2kAqEDYQ4DCyQRM2PFXVWCTsWE5a4CPVfMzvhJc60AO/PDuvSHyBFfF43Z47c3KS0EdCk+97Tj+mtImBQa1o4KRllVPI3B27arWAln+JrC1mKDtNluFtGBDl1vv+qcJSbnaPKnczzPCS06K2dalkEMFDoux4Xn61OZ683b2+s+56J6GpoiREEy3rWhXq5VHFOgrcsRi9jNWmcc1LnbK8iYnxGkGif4KtvMIsoAk4AzStpKTAotFYWvRyY6mxq02eBjUzkN4WAKnhHPz59jt/dH9kqkN0gtnVPPb45+bRXkCzOrwe9JUvv0KiH47Cg90L1oQc5Gq7kp2eWaN2cEycGMGfAziGAjSQRxFxGKMax/ROTJdGH29g+Y9PO1qXi1GsThsZ3yQgvU1Oh56TeUtPuR4tSOkK61N33zucLFWHrBGP6c3msG9PmNVZ/KGsJpAdTsDaQ/WBb30vV1/cP30Lgp22HNyzDEL+6LZKLCu8Ir8E6Pnj09QkICPHZqX8RujMPqT4r9M0/aVCUE"
cert = x509.load_der_x509_certificate(base64.b64decode(certBase64))
public_key = cert.public_key()
sign = int.from_bytes(cert.signature, byteorder="big", )

modBits = public_key.key_size
digest_cert = SHA256.new(cert.tbs_certificate_bytes)
r = int.from_bytes(pkcs15_encode(digest_cert, ceil_div(modBits, 8)), byteorder='big', signed=False)
date_str = (datetime.datetime.now() + datetime.timedelta(days=365)).strftime("%Y-%m-%d")

if os.path.exists('IDEs.json'):
    with open('IDEs.json', 'r') as f:
        ides = json.load(f)
else:
    ides = [
        {"code": "II", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "AC", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "DPN", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "RSC", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PS", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "RSF", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "GO", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "DM", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "CL", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "RS0", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "RC", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "RD", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "PC", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "RSV", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "RSU", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "RM", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "WS", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "DB", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "DC", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PDB", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PWS", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PGO", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PPS", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PPC", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PRB", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PSW", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PSI", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "PCWMP", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "DP", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "RS", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "QA", "paidUpTo": date_str, "fallbackDate": date_str, "extended": False},
        {"code": "DS", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "RR", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True},
        {"code": "AIP", "paidUpTo": date_str, "fallbackDate": date_str, "extended": True}
    ]
    with open('IDEs.json', 'w') as f:
        json.dump(ides, f, indent=4)

plugins = []
if os.path.exists('plugins.json'):
    with open('plugins.json', 'r') as f:
        plugins = json.load(f)
else:
    print("plugins.json not found. Generating this file form Jetbrains plugin repository.")
    with urllib.request.urlopen("https://plugins.jetbrains.com/files/pluginsXMLIds.json") as f:
        pluginsIds = json.load(f)
    processed_pid = 0
    for pid in reversed(pluginsIds):
        processed_pid += 1
        url = f"https://plugins.jetbrains.com/plugins/list?pluginId={urllib.parse.quote(pid)}"
        try:
            with urllib.request.urlopen(url) as f:
                plugin_rep = xmltodict.parse(f)
                if plugin_rep['plugin-repository']:
                    if type(plugin_rep['plugin-repository']['category']['idea-plugin']) is list:
                        plugin = plugin_rep['plugin-repository']['category']['idea-plugin'][0]
                    else:
                        plugin = plugin_rep['plugin-repository']['category']['idea-plugin']
                    # print(json.dumps(plugin, indent=2))
                    if 'productCode' in plugin:
                        code = plugin["productCode"]
                        plugins.append({"code": code, "paidUpTo": date_str, "fallbackDate": date_str, "extended": False })
        except:
            pass
            #print(f"bad url '{url}'")
        print(f"\r[{processed_pid}/{len(pluginsIds)}] found {len(plugins)} product codes", end='')
    with open('plugins.json', 'w') as f:
        json.dump(plugins, f, indent=4)
    print(".")

licenseId = gen_licenseId()
print("Licensee name:", end=" ")
name = input()
hash_str = f"{str(random.randrange(10000000,99999999))}/0:-{str(random.randrange(1000000000,9999999999))}"
licensePartDict = {
    "licenseId": licenseId,
    "licenseeName": name,
    "assigneeName": "",
    "assigneeEmail": "",
    "licenseRestriction": "",
    "checkConcurrentUse": False,
    "products": ides + plugins,
    "metadata": "0120230102PPAA013009",
    "hash": "41472961/0:1563609451",
    "gracePeriodDays": 7,
    "autoProlongated": True,
    "isAutoProlongated": True
}

licensePart = json.dumps(licensePartDict, separators=(',', ':'))
digest = SHA1.new(licensePart.encode('utf-8'))

private_key = RSA.import_key("""-----BEGIN RSA PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDHHzAZG9op3zFP8OTMs2KGaLkPYIQnO94SilZWcCJf2f6wVskdKu9yJfnMAGAt6s4lBI6vsDTOCb7XSn17aIUcloOe/L6ruKWw84bnYV0aorTSuxWPcgHr0oWm7UQhFgphr6d4BOIBJfK6K8JQCgjHGGSD9bo3HhEMA7LNB4kOloclEN1YyP1XB9/sozdD3yBX8+/8GhLanV6Fzj+i9dowH0QOA4P/FIyWsRS8uftbH4jEXqOtXZPeL77ISK+GXm5/e0onUKeP+WG/bAUyxYl5uG8oVk2nZsamCWtVswSKmoOh0hVdUjnVYBs6zaexkeuWix1lKyAX/B87IqW4eZsZAgMBAAECggEACW/GEeSO5OXb0onsL/LO6CeJoKvOa4UT781ATPmkuWXtguoj/xbAMQjRcyxv4nEyqpCyGeun/v05fv673me8SjfsXjIkb6MxMAcEhU3pEYh1ORjua0VIB8bq+Fedf1Np88n1LfQOSWdk3tOQ0oX9N0FFzzarp+3L+UWqGTsikM82RusD1aNnxtMK4pNXT7qD7ejXorDnHt1GW63fwZccXV9EWP5YvwYiE5s5MiMRlcjdj6gCw/TIeokmjuRIufl/KXJD75oQ0HXS4w/bLYdB/L9USmTXtnwD8NMAPBOx6jFig49rS6oRjPebeuYlSEwdg6+iqAkWaH1cDzImyGo/sQKBgQDq8vqtP5gSscnDUaaz0ryvnz1y71hZOAnZs5yBRN5e23qWKzR/eUmPimzT+ay/5qDZhTpZD2Nvi4Eu9nw7nZ9pAA305YqDliOyGEVHG5tlEV4TZrPV/y2vAH1oIGHAzh7+Af+BzEXu+26t+x8lR+eWcYOMy+6fWCVpjNagdq06yQKBgQDY9nBW4xcvwpHZFw7Hny7Pw1qnVLCDktI5udQ9CUcTRWzUMR3Q92zKJtWFkSHXNUeGP75j8dmsChi02F/rw43qihN9Y1ISv0Aedh6ih26YLB2mUmGu7TlwRCLn/dIYPFbeBMxLC/wmf8yGis++D9TGrhlu2i/yucdvv9tJSFk10QKBgFOkKq+wmw/UsTJSiBkuZbPT6clYAcjJVWBmO8odXVjBo9OAEBFteU2bhwCzutcaYJrvfgUkoE6eiF/SqgmDJLP5q/5KFVShB5YoY8lbv6dsVmRrxIvjaz0I3JxMIuDDwG7HAVIRCbh5VD6lzsGz5nM9eAqQsyOQ+sinteSsOyFZAoGBAKwLl/++aoeL8d3FRAoV96f3EK76IFLlnWD7NAsGjV8BwY/uNuebHKCc9NrKwJwIeuRBLffRM7wR8Y+OuVmao7HlthjLJq0JDY5aOmbFoHR5HzXhw+ZT5SVaUpfGldB0IKpEAcBNC7F3zDawYpYjtaWrLy3RRQ5kNXsvF3PgNCXRAoGAFSOBpD6BJP/gzhAxscwwq0KnlJ8oAnaWRlWrSmPC9k+sLLwYXXD01p3Eb+f7Spuk6ggVXxxmzaNloG8N0BPZf+90PF0uUDqzdWgoDBySDMPWeYp4t9CiDQAbO/GXeBb1kMi9pGPZ187g4z0rX5K8gOJf2NbaHiCI/Ekf6BB0qUY=
-----END RSA PRIVATE KEY-----""")
signature = pkcs1_15.new(private_key).sign(digest)

sig_results = base64.b64encode(signature)
licensePartBase64 = base64.b64encode(bytes(licensePart.encode('utf-8')))
public_key.verify(
    base64.b64decode(sig_results),
    base64.b64decode(licensePartBase64),
    padding=padding.PKCS1v15(),
    algorithm=hashes.SHA1(),
)
result = licenseId + "-" + licensePartBase64.decode('utf-8') + "-" + sig_results.decode('utf-8') + "-" + certBase64
key_filename = f'{licenseId}_key.txt'
with open(key_filename, 'w') as f:
    f.write(result)
print(f'Activation key stored to {key_filename}')
input()