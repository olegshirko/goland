#!/bin/sh

# 1. Copy license.jar to home directory
cp "$(dirname "$0")/license.jar" "$HOME/"

# 2. Determine the full path to the home directory
FULL_HOME_PATH=$(eval echo ~)

# 3. Define the primary and fallback vmoptions file paths
PRIMARY_VMOPTIONS_FILE="$HOME/Library/Application Support/JetBrains/GoLand2025.3/goland.vmoptions"
FALLBACK_VMOPTIONS_FILE="/Applications/GoLand.app/Contents/bin/goland.vmoptions"

# Lines to be added
VM_OPTIONS_LINES="
--add-opens=java.base/jdk.internal.org.objectweb.asm=ALL-UNNAMED
--add-opens=java.base/jdk.internal.org.objectweb.asm.tree=ALL-UNNAMED
-javaagent:${FULL_HOME_PATH}/license.jar
"

# Function to append options if they don't exist
append_options() {
    local file=$1
    if grep -q "javaagent:.*license.jar" "$file"; then
        echo "Agent already configured in $file. Skipping."
    else
        echo "Updating vmoptions file: $file"
        echo "$VM_OPTIONS_LINES" >> "$file"
    fi
}

# 4. Check for the primary vmoptions file and append the lines
if [ -f "$PRIMARY_VMOPTIONS_FILE" ]; then
    append_options "$PRIMARY_VMOPTIONS_FILE"
# 5. If the primary file doesn't exist, use the fallback file
else
    if [ -f "$FALLBACK_VMOPTIONS_FILE" ]; then
        append_options "$FALLBACK_VMOPTIONS_FILE"
    else
        echo "Error: Neither primary nor fallback vmoptions file found."
        exit 1
    fi
fi

echo "Installation script finished."