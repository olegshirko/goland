Copy license.jar to home dir

cp ./license.jar $HOME 

Add to "Edit Custom VM Options" menu item in IDE Help menu section:

-javaagent:/Users/user/license.jar


python3 -m venv venv
source venv/bin/activate
python3 -m pip install

pip3 install -r requirements.txt
python3 kg.py


